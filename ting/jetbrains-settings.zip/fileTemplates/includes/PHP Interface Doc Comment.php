/**
 * Interface ${NAME}
#if (${NAMESPACE}) * @package ${NAMESPACE}
#end
 * @author Hylea Soo
 */
